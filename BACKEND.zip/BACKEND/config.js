module.exports = {
    db: {
      mongoURI: `mongodb+srv://migueladmin:miguel2828@cluster0.0ujtvtv.mongodb.net/`,
    },
    TOKEN_SECRET: 'tu-secreto-de-jwt-aqui'
  };
  