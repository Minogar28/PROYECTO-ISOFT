const joi = require('joi');

const schema = {
}

module.exports = schema;
